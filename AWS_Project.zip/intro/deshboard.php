<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Center the content vertically */
            background-image: url('https://wallpapercave.com/wp/wp9764014.jpg'); /* Replace with your image URL */
            background-size: cover; /* Adjust as needed */
            background-repeat: no-repeat;
        }

        .container {
            width: 70VW;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);  /* Add a semi-transparent white background */
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative; /* To position the icons */
        }

        .form-group i {
            position: absolute;
            left: 10px; /* Adjust the left position as needed */
            top: 50%; /* Center vertically */
            transform: translateY(-50%);
            color: #aaa; /* Icon color */
        }

        input[type="text"],
        input[type="password"] {
            width: 85%;
            padding: 10px 30px; /* Add padding for the icon */
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .remember-forgot-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
        }
        .alert-success{
            padding: 10px;
    background-color: #00800094;
        }


        table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.session-data{
    color: red;
    background-color: greenyellow;
    padding: 10px;
    font-weight: bold;
}



    </style>
</head>
<?php include('connection.php');
$msg ='';
if(isset($_GET['del_id'])){
    $del_id = $_GET['del_id'];
    $rule = array();
    $rule['id'] = $del_id;
    db_delete("register", $rule);
    $msg = "Record Deleted Successfully";
}
 

if(!isset($_SESSION['name'])){
    header("Location: login.php");
}
 $sql="select * from register";
 $result=mysqli_query($conn,$sql);
 

   
?>
<body>
     
    <div class="container">
    <span class="session-data">Full Name : <?=$_SESSION["name"] ?></span> &nbsp;
        <span class="session-data">User Name : <?= $_SESSION["userName"] ?></span>
        <a class="session-data" href="logout.php">LogOut</a>
        
        <h2>User List</h2>
        <?php if ($msg != "") {
          ?>
          <div class="alert-success">
          <?php echo $msg; ?>
          </div>
          <?php
            }
          ?>
        <table>
        <tr>
            <th>Sl. No.</th>
            <th>Full Name</th>
            <th>Email Id</th>
            <th>User Name</th>
            <th>Address</th>
            <th>Image </th>
            <th>Delete</th>
        </tr>
        <?php $i = 0;
                while($row = mysqli_fetch_assoc($result)){ $i++;
                    if($row['roll']!='admin') {
        ?>
        <tr>
            <td><?= $i ?></td>
            <td><?= $row['fName'] ?></td>
            <td><?= $row['emailId'] ?></td>
            <td><?= $row['userName'] ?></td>
            <td><?= $row['address'] ?></td>
             <td><a href="upload/<?= $row['image'] ?>" target="_blank" rel="noopener">Click</a></td>
            <td>
            <a href="deshboard.php?del_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger delete"><i class="fa fa-trash"></i> Delete</a>
            </td>
        </tr>
        <?php } } ?>
  
   
  
</table>
         
    </div>
</body>
</html>