<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
 <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Center the content vertically */
            background-image: url('https://wallpapercave.com/wp/wp9764014.jpg'); /* Replace with your image URL */
            background-size: cover; /* Adjust as needed */
            background-repeat: no-repeat;
        }

        .container {
            width: 30VW;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);  /* Add a semi-transparent white background */
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative; /* To position the icons */
        }

        .form-group i {
            position: absolute;
            left: 10px; /* Adjust the left position as needed */
            top: 50%; /* Center vertically */
            transform: translateY(-50%);
            color: #aaa; /* Icon color */
        }

        input[type="text"],
        input[type="password"] {
            width: 85%;
            padding: 10px 30px; /* Add padding for the icon */
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .remember-forgot-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
        }
        .alert-success{
            padding: 10px;
    background-color: #00800094;
        }
    </style>
</head>

<body>
<?php include('connection.php');
$msg="";


if (isset($_POST["submit"]))
{ 
  $fname     = $_POST['fullName'];
  $userName  = $_POST['username']; 
  $emailId   = $_POST['emailId'];
  $address   = $_POST['address'];
  $password  = $_POST['password']; 
  $image     = $_FILES['image'];
   
    if($_FILES['image']['name']!==0)
     {
        $photo=$_FILES['image']['name'];
        $temp = explode(".", $_FILES["image"]["name"]);
        $newfilename = round(microtime(true)) . '.' . end($temp);
        move_uploaded_file($_FILES['image']['tmp_name'],'upload/'.$newfilename);
     }
      
  $sql="INSERT INTO register(fName,userName,emailId,address,password,image)VALUES('$fname','$userName','$emailId','$address','$password','$newfilename')";
  //print_r($sql);die;
    $result=mysqli_query($conn,$sql);
    $msg="User registered successfully";
 

}
 
 
?>  
 
<div class="container">
<?php
              if ($msg != "") {
          ?>
          <div class="alert-success">
          <?php echo $msg; ?>
          </div>
          <?php
            }
          ?>
        <h2>Sing Up</h2>
        <form action="#" method="post" enctype="multipart/form-data">
        <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" id="fullName" name="fullName" placeholder="Full Name" required>
            </div>
            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>

            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" id="emailId" name="emailId" placeholder="Email Id" required>
            </div>
             
            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" id="address" name="address" placeholder="Full Address" required>
            </div>
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
               <p>Upload CV</p>
               <input type="file" name="image"  />
            </div>
            <div class="form-group">
                <div class="remember-forgot-container">
                    <label for="remember-me"><input type="checkbox" id="remember-me" name="remember-me"> Remember Me</label>
                    <a href="#">Forgot Password</a>
                </div>
            </div>
            <div class="form-group">
                <input type="submit" name="submit" value="Register">
            </div> 
        </form>
        <div class="signup-link">
        Already have an account? <a href="login.php">LOGIN</a>
        </div>
    </div>
</body>
</html>