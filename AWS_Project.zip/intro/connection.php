<?php session_start();
$servername = "localhost";
$username = "gateways_2023";
$password = "{]qgtV.?qSIT";
$db = "gateways_2023";
// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

function db_first($sql){
    $rest = db_select($sql);
    if(isset($rest[0])){
        return $rest[0];
    }else{
        return false;
    }
}
function db_delete($table, $rules = array())
{
    global $conn;
    $sql = "DELETE FROM $table ";
    $where = "";
    foreach ($rules as $n => $v) {
        $where .= $n . "='" . $v . "',";
    }
    $where = rtrim($where, ",");
    $sql .= " WHERE " . $where;
    $conn->query($sql);
}
?>