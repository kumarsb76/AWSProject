<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Center the content vertically */
            background-image: url('https://wallpapercave.com/wp/wp9764014.jpg'); /* Replace with your image URL */
            background-size: cover; /* Adjust as needed */
            background-repeat: no-repeat;
        }

        .container {
            width: 30VW;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);  /* Add a semi-transparent white background */
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative; /* To position the icons */
        }

        .form-group i {
            position: absolute;
            left: 10px; /* Adjust the left position as needed */
            top: 50%; /* Center vertically */
            transform: translateY(-50%);
            color: #aaa; /* Icon color */
        }

        input[type="text"],
        input[type="password"] {
            width: 85%;
            padding: 10px 30px; /* Add padding for the icon */
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .remember-forgot-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
        }
        .alert-success{
            padding: 10px;
    background-color: #00800094;
        }
    </style>
</head>
<?php include('connection.php');
$msg="";
if(isset($_POST['login']))
{
  
$userName=$_POST['username'];
$password=$_POST['password'];

$sql="select * from register where userName='$userName' and password='$password'";
$res= mysqli_query($conn,$sql);
        if ($res->num_rows > 0) {
            $row = $res->fetch_assoc();
             $_SESSION['uid'] = $row['id'];
             $_SESSION['name'] = $row['fName'];
             $_SESSION['userName'] = $row['userName'];

             if($row['roll'] == 'admin'){
                header("location:deshboard.php");
             }
             else{
                header("location:user-deshboard.php");
             }
             
            exit;
          }

        else
        {

            $msg="Invalid User Name and password";
        } 
}
   
?>
<body>
    <div class="container">
    <?php
              if ($msg != "") {
          ?>
          <div class="alert alert-success">
          <?php echo $msg; ?>
          </div>
          <?php
            }
          ?>
        <h2>Login</h2>
        <form action="#" method="post">
            <div class="form-group">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" placeholder="Username" required>
            </div>
            <div class="form-group">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <div class="remember-forgot-container">
                    <label for="remember-me"><input type="checkbox" id="remember-me" name="remember-me"> Remember Me</label>
                    <a href="#">Forgot Password</a>
                </div>
            </div>
            <div class="form-group">
                <input type="submit" name="login" value="Login">
            </div> 
        </form>
        <div class="signup-link">
            Don't have an account? <a href="signup.php">Sign Up</a>
        </div>
    </div>
</body>
</html>