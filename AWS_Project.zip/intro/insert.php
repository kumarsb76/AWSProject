<?php
 
$fullName =  $_REQUEST['fullName'];
$userName = $_REQUEST['username'];
$emailId =  $_REQUEST['emailId'];
$address = $_REQUEST['address'];
$password = $_REQUEST['password'];
 
// Performing insert query execution
// here our table name is college
$sql = "INSERT INTO register  VALUES ('$fullName', 
    '$userName','$emailId','$address','$password')";
 
if(mysqli_query($conn, $sql)){
    echo "<h3>data stored in a database successfully."
        . " Please browse your localhost php my admin"
        . " to view the updated data</h3>"; 

    echo nl2br("\n$fullName\n $userName\n "
        . "$emailId\n $address\n $password");
} else{
    echo "ERROR: Hush! Sorry $sql. "
        . mysqli_error($conn);
}
echo "Connected successfully";
?>