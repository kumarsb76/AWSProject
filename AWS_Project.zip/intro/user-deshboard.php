<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Center the content vertically */
            background-image: url('https://wallpapercave.com/wp/wp9764014.jpg'); /* Replace with your image URL */
            background-size: cover; /* Adjust as needed */
            background-repeat: no-repeat;
        }

        .container {
            width: 70VW;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.9);  /* Add a semi-transparent white background */
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative; /* To position the icons */
        }

        .form-group i {
            position: absolute;
            left: 10px; /* Adjust the left position as needed */
            top: 50%; /* Center vertically */
            transform: translateY(-50%);
            color: #aaa; /* Icon color */
        }

        input[type="text"],
        input[type="password"] {
            width: 85%;
            padding: 10px 30px; /* Add padding for the icon */
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .remember-forgot-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        input[type="checkbox"] {
            margin-right: 5px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .signup-link {
            text-align: center;
            margin-top: 10px;
        }
        .alert-success{
            padding: 10px;
    background-color: #00800094;
        }


        table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

.session-data{
    color: red;
    background-color: greenyellow;
    padding: 10px;
    font-weight: bold;
}



    </style>
</head>
<?php include('connection.php');
$userId =  $_SESSION['uid'];

if(!isset($_SESSION['name'])){
    header("Location: login.php");
}
 $sql="select * from register where id = $userId";
 $result=mysqli_query($conn,$sql);
 $row = mysqli_fetch_assoc($result);
 
   
?>
<body>
     
    <div class="container">
     
        <a class="session-data" href="logout.php">LogOut</a>
        
        <h2>User List</h2>

            <hr/>
            <div class="row">
                <div class="col-sm-6">
                    <p> Full Name  : <?= $row['fName'] ?></p>
                </div>
                <div class="col-sm-6">
                    <p> Email ID  : <?= $row['emailId'] ?></p>
               </div>
        </div>
        <div class="row">
                <div class="col-sm-6">
                    <p> User Name  : <?= $row['userName'] ?></p>
                </div>
                <div class="col-sm-6">
                    <p> Password  : <?= $row['password'] ?></p>
               </div>
        </div>
        <div class="row">
                <div class="col-sm-6">
                    <p> Address  : <?= $row['address'] ?></p>
                </div>
                 <div class="col-sm-6">
                    <p> CV  : <a href="upload/<?= $row['image'] ?>" target="_blank" rel="noopener">Click</a></p>
                </div>
                
        </div>
    </div>
</body>
</html>